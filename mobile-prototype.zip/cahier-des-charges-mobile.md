# MOBILE — Cahier des charges technique

**Affaire n°1 : La nuit de la gerbebaude**, du prototype HTML à une vraie app avec comptes.

Version 1.0 · novembre 2026 · auteur : Elie (PM)

---

## Comment utiliser ce document

Ce fichier sert de référence pour développer l'application dans VS Code, avec Claude Code ou à la main. Il accompagne le prototype livré dans `mobile-prototype.zip`, qui contient :

| Fichier | Rôle |
|---|---|
| `prototype/index.html` | Le jeu complet en un seul fichier : interface, moteur, contenu de l'affaire. **Il fait foi pour les règles du jeu.** |
| `prototype/faces/*.jpg` | Les 101 portraits : 100 suspects et la victime. |
| `prototype/ev/*.jpg` | Les 23 photos des pièces. Chaque photo existe en version pleine (`nom.jpg`, 1600 px) et vignette (`nom_m.jpg`, 720 px). |
| `data/suspects.json` | Les 100 fiches suspects, au format source. |

Pour lancer le prototype, ouvre `prototype/index.html` dans Chrome. Les images doivent rester dans leurs dossiers, à côté du fichier. Le code de sauvegarde « compte claude.ai » du prototype ne fait rien hors de claude.ai : c'est normal.

La section 19 donne le fichier `CLAUDE.md` à placer à la racine du projet, puis les premiers prompts à lancer.

---

## 0. Les décisions en bref

1. **Une web app installable (PWA) d'abord**, publiée sur les stores dans un second temps avec Capacitor.
2. **Stack** : Next.js (App Router) + TypeScript, Supabase (Postgres, Auth, Storage, cron), Vercel, Web Push.
3. **Moteur de jeu en TypeScript pur**, sans React ni DOM. Le même code tourne côté client et côté serveur.
4. **Le serveur fait autorité** sur le temps et les résultats. Le joueur ne peut ni avancer l'horloge de son téléphone, ni lire la solution dans le code.
5. **Les affaires sont des données** (JSON versionné), pas du code. Une nouvelle affaire ne demande pas de redéploiement du moteur.
6. **Une seule ligne `games` par partie**, avec l'état complet en `jsonb` (environ 15 ko mesuré sur une partie complète), plus un journal des commandes.
7. **Comptes** : connexion par lien e-mail, Google et Apple. On peut jouer en invité, puis rattacher un compte sans perdre sa partie.
8. **Retour du joueur** : écran « Pendant votre absence » et notifications push quand un résultat arrive, avec heures de silence.
9. **Hébergement en Europe** (Supabase région UE, fonctions Vercel à Paris) et données personnelles minimales.
10. **Livraison en 6 lots**, chacun testable (section 16).

---

## 1. Le produit

### 1.1 Le concept

Un jeu d'enquête policière solo, réaliste, qui se joue sur plusieurs jours. Un meurtre a eu lieu pendant la fête de fin des vendanges d'un château bordelais. Il y a 100 présents, et 5 jours pour transmettre un nom et un dossier au parquet.

### 1.2 La boucle de jeu (règles du prototype)

**Le temps**
- L'horloge du jeu compte en minutes depuis le samedi 0h. La partie commence samedi à 8h (minute 480) et le délai tombe mercredi à 20h (minute `4×1440+1200`).
- Le joueur dispose de 3 actions par jour, de 8h à 20h. La nuit, les services sont fermés.
- Chaque action rend son résultat après un délai : de 30 min à 3 jours.
- Certains événements surviennent seuls (autopsie, rapport des techniciens, cambriolage, retour de l'avocate, aveu de Claire, délai). Ce sont les événements « auto ».
- Il y a deux rythmes :
  - **accéléré** : le joueur avance le temps lui-même ;
  - **temps réel** : l'affaire dure vraiment 5 jours.

**Le tri**
- Les 100 suspects sont des cartes à trier en swipe :
  - à gauche pour écarter ;
  - en bas pour mettre en doute ;
  - à droite pour garder.
- Trois boutons équivalents remplacent le swipe pour qui le souhaite.
- On trie **motif par motif** : un motif est un critère débloqué par un indice. Le motif « à l'instinct » est toujours disponible.
- Chaque écart garde la trace du motif utilisé. Si un témoignage s'avère faux, les cartes écartées sur ce motif reviennent en doute.
- On garde **10 suspects au maximum**. Les suspects gardés sont épinglés sur le tableau.
- Téléphone, comptes, ADN et accusation ne visent que les suspects gardés.

**Le tableau**
- C'est le mur d'enquête, avec zoom et déplacement. On y épingle :
  - les photos des suspects ;
  - les pièces ;
  - des post-it.
- On relie les éléments par des fils typés : mobile, opportunité, preuve, alibi, ou simple lien.

**Les interrogatoires**
- Le joueur confronte une déclaration à une pièce.
- Une bonne confrontation fait craquer le suspect. Si elle apporte une pièce nouvelle, elle rend une action.
- Une mauvaise confrontation coûte 25 points.
- Après 3 erreurs, le suspect se tait jusqu'au lendemain.

**Le commandant**
- Une fois par jour, et au prix d'une action, il relit les fils typés et dit lesquels tiennent.

**L'accusation et le score**
- Le joueur désigne un suspect. Les fils de sa photo forment le dossier transmis au parquet.
- Barème :
  - bon coupable : +200 ;
  - chaque volet prouvé (mobile, opportunité, preuve) : +150 ;
  - coupable jamais écarté : +100, seulement si le dossier est plein ;
  - chaque jour d'avance : +50, seulement si le dossier est plein ;
  - chaque mauvaise confrontation : −25.
- Issues possibles :
  - `plein` : bon coupable et 3 volets prouvés ;
  - `fragile` : 2 volets ;
  - `vide` : 0 ou 1 volet ;
  - `faux` : mauvais coupable.
- Grades : Major ≥ 800, Adjudant-chef ≥ 650, Adjudant ≥ 500, Maréchal des logis-chef ≥ 300, Gendarme en dessous.

### 1.3 Ce qu'apporte la vraie app

| Prototype | Vraie app |
|---|---|
| Sauvegarde dans le navigateur | Partie liée au compte, reprise sur n'importe quel appareil |
| Horloge calculée sur le téléphone | Horloge et résultats calculés par le serveur |
| Tout le contenu dans le HTML, solution comprise | Le joueur ne reçoit que ce qu'il a débloqué |
| Rien ne fait revenir le joueur | Notifications push, écran de retour, annonce du lendemain |
| Une seule affaire | Catalogue d'affaires, contenu versionné |
| Aucune mesure | Analytics produit, suivi des erreurs |

### 1.4 Hors périmètre de la V1

Le multijoueur, le mode jurés, l'éditeur d'affaires, les paiements, les classements publics et la traduction sont hors V1. Le modèle de données les permet, mais ils ne seront pas développés.

---

## 2. Plateforme : PWA d'abord, stores ensuite

| Option | Pour | Contre |
|---|---|---|
| **PWA (Next.js)** : retenue pour la V1 | Une seule base de code, déploiement immédiat, notifications push y compris sur iPhone, partage par lien | Sur iPhone, les notifications ne marchent qu'une fois l'app ajoutée à l'écran d'accueil (iOS 16.4 et plus) |
| App native (Capacitor) : V2 | Présence sur les stores, notifications natives fiables | Revue Apple : la règle 4.2 refuse les simples sites encapsulés, il faudra une vraie valeur native |
| React Native / Expo | Rendu natif | Réécriture complète de l'interface, deux bases de code |

**Décision.** Construire une PWA propre, puis l'encapsuler avec Capacitor (lot 6) en ajoutant les notifications natives. Le code métier ne change pas.

---

## 3. Stack technique

| Couche | Choix | Pourquoi |
|---|---|---|
| Framework | **Next.js** (App Router), **TypeScript** strict | Front et API dans un même projet, déploiement Vercel natif |
| Style | **Tailwind CSS**, avec les variables de couleur du prototype en tokens | Rapide à itérer. On reprend la charte du prototype : nuit, papier, gyrophare, fils colorés. |
| Gestes | **@use-gesture/react** + **motion** (ex-framer-motion) | Swipe des cartes, déplacement et zoom du tableau, pincement dans la visionneuse |
| État client | **Zustand** | État de l'écran : sélection, onglets, file de commandes |
| Données serveur | **@supabase/supabase-js**, **@supabase/ssr**, **@tanstack/react-query** | Session, cache, invalidation |
| Base de données | **Supabase Postgres** | Relationnel, `jsonb`, sécurité par ligne (RLS), temps réel |
| Authentification | **Supabase Auth** | Lien magique, Google, Apple, connexion anonyme puis rattachement |
| Fichiers | `public/` en V1, puis **Supabase Storage** | Portraits et photos des pièces |
| Tâches planifiées | **pg_cron + pg_net** (Supabase), qui appellent une route Next.js chaque minute | Envoi des notifications à l'heure. Le cron de Vercel est limité sur les petits plans. |
| Notifications | **Web Push** (clés VAPID, librairie `web-push`) ; e-mail en option avec **Resend** | Standard, gratuit, fonctionne sur Android, ordinateur et iPhone installé |
| PWA | **Serwist** (`@serwist/next`, successeur de next-pwa) | Service worker, cache hors ligne, réception des push |
| Tests | **Vitest** pour le moteur, **Playwright** pour les parcours | Le prototype a déjà un scénario Playwright de référence |
| Analytics | **PostHog**, hébergement UE | Entonnoirs, rétention, flags |
| Erreurs | **Sentry** (`@sentry/nextjs`) | Erreurs client et serveur |
| Hébergement | **Vercel** (région `cdg1`, Paris) et **Supabase** (région UE) | Les données restent en Europe |

À l'installation, prends les **versions stables du moment**. Ce document ne fige pas de numéro de version.

---

## 4. Architecture

```
┌──────────────────────────── Téléphone / navigateur ────────────────────────────┐
│  PWA Next.js (React)                                                           │
│  ├─ Écrans : Tri · Tableau · Enquête · Pièces · Interrogatoire · Verdict       │
│  ├─ Moteur (src/engine), copie locale pour l'affichage immédiat                │
│  ├─ File de commandes hors ligne (IndexedDB)                                   │
│  └─ Service worker : cache des images, réception des notifications             │
└───────────────▲─────────────────────────────────────────────┬──────────────────┘
                │ vue joueur (contenu débloqué seulement)     │ commandes
┌───────────────┴─────────────────────────────────────────────▼──────────────────┐
│  Next.js · route handlers (Node, région Paris)                                 │
│  POST /api/games/:id/commands → charge la partie → rattrapage du temps         │
│  → applique la commande (moteur) → enregistre (verrou optimiste)               │
│  → planifie les notifications → renvoie la vue joueur                          │
│  Contenu des affaires : content/cases/** (importé côté serveur uniquement)     │
└───────────────▲─────────────────────────────────────────────┬──────────────────┘
                │                                             │
┌───────────────┴─────────────── Supabase (UE) ───────────────▼──────────────────┐
│  Auth · Postgres (profiles, cases, games, game_commands, notifications,        │
│  push_subscriptions) · Storage · Realtime                                      │
│  pg_cron (chaque minute) ─ pg_net ─▶ POST /api/cron/notifications ─▶ Web Push   │
└────────────────────────────────────────────────────────────────────────────────┘
```

### 4.1 Le moteur, un module pur

Le dossier `src/engine/` ne dépend ni de React, ni du DOM, ni de Supabase. Il reçoit l'état, la commande, le contenu de l'affaire et l'heure réelle, et renvoie un nouvel état.

```ts
// src/engine/index.ts : surface publique du moteur
export function createGame(c: CaseData, mode: Mode, now: Date, seed: number): GameState;
export function currentMinute(g: GameState, now: Date): Minute;          // temps réel : ancre + écoulé
export function catchUp(g: GameState, c: CaseData, now: Date): Result;   // fait arriver ce qui est dû
export function applyCommand(g: GameState, cmd: Command, c: CaseData, now: Date): Result;
export function playerView(g: GameState, c: CaseData): PlayerView;       // contenu débloqué seulement
export function upcoming(g: GameState, c: CaseData): Upcoming[];         // résultats et rendez-vous à venir
export function score(g: GameState, c: CaseData, suspectId: number): Verdict;

export type Result = { state: GameState; events: GameEvent[]; error?: EngineError };
```

**Règles d'implémentation du moteur**
- **Déterministe.** Aucun `Date.now()` ni `Math.random()` dans le moteur. L'heure arrive en paramètre, et le hasard vient d'un générateur à graine, stockée dans l'état.
- **Immuable.** Chaque commande renvoie un nouvel état. C'est ce qui permet l'annulation, le rejeu et les tests.
- **Erreurs typées.** Exemples : `PLUS_D_ACTION`, `HORS_HORAIRES`, `CIBLE_NON_GARDEE`, `TABLEAU_PLEIN`, `SUSPECT_MUET`, `PARTIE_TERMINEE`.

### 4.2 Le serveur fait autorité

Les commandes qui touchent au temps, aux actions ou au score passent par le serveur :
- lancer une action ;
- avancer le temps ;
- confronter ;
- demander l'avis du commandant ;
- accuser ;
- changer de rythme.

Le client applique la commande en local pour un retour immédiat, puis se recale sur la réponse du serveur.

Le tri et la disposition du tableau sont fréquents et sans enjeu de triche. Ils partent par lots toutes les 2 secondes. Le serveur revérifie quand même la limite de 10 suspects gardés.

### 4.3 L'horloge

| Mode | Calcul |
|---|---|
| Accéléré | `games.game_minute` ne bouge qu'avec la commande `advance` |
| Temps réel | `minute = anchor_minute + floor((now − anchor_real) / 60 000)`, toujours calculé avec l'heure du **serveur** |

À chaque lecture ou commande, le serveur appelle `catchUp`. Tout ce qui était dû arrive : résultats, événements auto, nouvelle journée.

> **Point de conception à trancher (recommandation).** Dans le prototype, la partie en temps réel commence « samedi 8h » à l'instant du clic. L'horloge du jeu est alors décalée par rapport à la vraie journée : une partie lancée à 21h donne des journées de jeu qui se terminent en pleine nuit. **Recommandation** : caler l'horloge du jeu sur l'heure locale du joueur.
> - Si le joueur démarre avant 17h, le jour 1 commence tout de suite, avec l'heure réelle.
> - S'il démarre plus tard, il reçoit le constat et peut lancer ses 3 premières actions le soir même. Le jour 1 officiel commence le lendemain à 8h.
>
> Les nuits du jeu tombent alors pendant les vraies nuits, et les heures de silence des notifications se gèrent toutes seules.

### 4.4 Hors ligne

- Les écrans déjà chargés restent consultables : dossier, pièces, tableau, photos en cache.
- Les commandes de tri et de tableau se mettent en file (IndexedDB) et sont rejouées au retour du réseau.
- Les commandes qui demandent le serveur (lancer une action, accuser…) sont désactivées hors ligne. Un message l'explique au joueur.

---

## 5. Base de données

### 5.1 Schéma

Ce code va dans `supabase/migrations/0001_init.sql`.

```sql
-- Profils (1 ligne par compte, créée automatiquement)
create table public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  pseudo        text,
  timezone      text not null default 'Europe/Paris',
  notif_results boolean not null default true,   -- push quand un résultat arrive
  notif_daily   boolean not null default true,   -- push « nouvelle journée » et annonce du soir
  quiet_start   smallint not null default 21,    -- heures de silence, heure locale
  quiet_end     smallint not null default 8,
  created_at    timestamptz not null default now()
);

-- Catalogue des affaires (le contenu lui-même est dans content/cases/**)
create table public.cases (
  id          text primary key,          -- 'affaire-1'
  version     int  not null,             -- version de contenu servie aux nouvelles parties
  title       text not null,
  subtitle    text,
  cover_url   text,
  published   boolean not null default false,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now()
);

create type game_mode   as enum ('acc', 'reel');
create type game_status as enum ('en_cours', 'terminee', 'abandonnee');

-- Parties
create table public.games (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null references auth.users(id) on delete cascade,
  case_id            text not null references public.cases(id),
  case_version       int  not null,             -- la partie reste sur sa version de contenu
  mode               game_mode   not null default 'acc',
  status             game_status not null default 'en_cours',
  game_minute        int  not null default 480, -- minutes depuis samedi 0h
  anchor_real        timestamptz,               -- temps réel : instant de référence
  anchor_minute      int,                       -- temps réel : minute de jeu à cet instant
  state              jsonb not null,            -- état complet du moteur (~15 ko)
  state_version      int  not null default 1,   -- verrou optimiste
  last_seen_at       timestamptz,               -- pour « Pendant votre absence »
  last_seen_journal  int  not null default 0,
  outcome            text,                      -- plein | fragile | vide | faux
  score              int,
  grade              text,
  started_at         timestamptz not null default now(),
  ended_at           timestamptz,
  updated_at         timestamptz not null default now()
);
create unique index games_une_active on public.games(user_id, case_id) where status = 'en_cours';
create index games_par_joueur on public.games(user_id, updated_at desc);

-- Journal des commandes (audit, rejeu, analyse)
create table public.game_commands (
  id          bigint generated always as identity primary key,
  game_id     uuid not null references public.games(id) on delete cascade,
  user_id     uuid not null references auth.users(id) on delete cascade,
  type        text not null,
  payload     jsonb not null default '{}',
  game_minute int  not null,
  created_at  timestamptz not null default now()
);
create index game_commands_par_partie on public.game_commands(game_id, id);

-- Abonnements push (un par appareil)
create table public.push_subscriptions (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  channel     text not null default 'web',      -- web | fcm | apns (V2 native)
  endpoint    text not null unique,             -- web : endpoint ; natif : jeton
  p256dh      text,
  auth        text,
  user_agent  text,
  created_at  timestamptz not null default now()
);

-- Notifications planifiées
create table public.notifications (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  game_id      uuid not null references public.games(id) on delete cascade,
  kind         text not null,          -- resultat | nouvelle_journee | annonce_soir | delai
  fire_at      timestamptz not null,
  title        text not null,
  body         text not null,
  url          text not null,          -- écran à ouvrir au toucher
  dedupe_key   text not null unique,   -- ex. game_id:resultat:bluestar:2880
  sent_at      timestamptz,
  cancelled_at timestamptz
);
create index notifications_dues on public.notifications(fire_at)
  where sent_at is null and cancelled_at is null;

-- Création automatique du profil
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id);
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();
```

### 5.2 Sécurité par ligne (RLS)

Le client lit, mais **n'écrit jamais directement une partie**. Toutes les écritures de jeu passent par les routes serveur, avec la clé `service_role`.

```sql
alter table public.profiles           enable row level security;
alter table public.cases              enable row level security;
alter table public.games              enable row level security;
alter table public.game_commands      enable row level security;
alter table public.push_subscriptions enable row level security;
alter table public.notifications      enable row level security;

create policy "profil : soi-même" on public.profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "affaires publiées" on public.cases
  for select using (published);
create policy "parties : lecture par soi" on public.games
  for select using (auth.uid() = user_id);
create policy "commandes : lecture par soi" on public.game_commands
  for select using (auth.uid() = user_id);
create policy "push : soi-même" on public.push_subscriptions
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
-- notifications : aucune policy, accès serveur uniquement
```

### 5.3 Verrou optimiste

Chaque écriture se fait sous condition de version :

```sql
update games set state = $state, state_version = state_version + 1, ...
where id = $id and state_version = $version_lue;
```

Si aucune ligne n'est modifiée, un autre appareil a joué entre-temps. Le serveur recharge alors la partie, rejoue la commande sur le nouvel état et réessaie une fois.

### 5.4 Synchronisation entre appareils

Le client s'abonne en temps réel (Supabase Realtime, `postgres_changes` sur `games`, filtré par `id`). Une partie ouverte sur l'ordinateur se met donc à jour quand on joue sur le téléphone.

---

## 6. Le contenu des affaires

### 6.1 Format

Une affaire est un dossier versionné dans git :

```
content/cases/affaire-1/
  case.json            métadonnées, début, délai, textes d'intro, version
  suspects.json        100 fiches (repris de data/suspects.json)
  victim.json
  evidence.json        pièces : titre, type, personnes citées, texte
  pictures.json        photos rattachées aux pièces (fichier, légende, portrait ou paysage)
  phones.json          résultats des réquisitions téléphone (TEL du prototype)
  banks.json           résultats bancaires (BANQUE)
  actions.json         actions : délais, disponibilité, conditions, effets, texte de notification
  auto.json            événements automatiques (AUTO)
  interrogations.json  déclarations, pièces qui les cassent, réponses, pièces gagnées (INTERRO)
  motifs.json          motifs de tri (MOTIFS)
  proof.json           ce que chaque pièce prouve, et sur qui (PROOF) ; SECRET
  scoring.json         barème et grades
public/cases/affaire-1/faces/*.jpg
public/cases/affaire-1/ev/*.jpg
```

**Règle anti-spoiler.** Les fichiers de `content/` ne sont importés **que** côté serveur (`import "server-only"`). Le client ne reçoit que la `playerView` : les pièces débloquées, les déclarations entendues et les fiches suspects. `proof.json`, les aveux et les pièces à venir ne quittent jamais le serveur.

### 6.2 Conditions déclaratives

Le prototype écrit ses conditions en JavaScript, par exemple `req: s => has(s, "tic")`. Dans l'app, elles deviennent des données :

```ts
type Cond =
  | { has: string }                 // pièce obtenue
  | { evInvalid: string }           // pièce invalidée (fausse piste)
  | { done: string }                // action terminée
  | { flag: string }                // drapeau d'état (ex. "jlOut")
  | { minuteAtLeast: number }       // heure de jeu atteinte
  | { not: Cond } | { all: Cond[] } | { any: Cond[] };
```

Exemple, l'action « Relever le piège photo » :

```json
{
  "id": "piege",
  "title": "Relever le piège photo de l'allée",
  "desc": "Posé contre les sangliers à l'entrée du domaine.",
  "delay": 120,
  "req": { "has": "mathis" },
  "reqText": "Après les témoignages du dortoir.",
  "effects": [{ "addEv": "piege_photo" }],
  "resultText": "Une berline sombre passe le portail à 02h21, phares éteints.",
  "notif": { "title": "Le piège photo a parlé", "body": "Une voiture est passée cette nuit-là. Ouvrez le dossier." }
}
```

Les quelques règles propres à une affaire restent du code, dans des **gestionnaires nommés** que le JSON référence (`{ "special": "adnCompare" }`). Exemples dans l'affaire n°1 :
- la comparaison ADN ;
- le cahier de chai qui disparaît après le cambriolage ;
- l'invalidation du témoignage de la voiture.

Ces gestionnaires vont dans `src/engine/cases/affaire-1.ts`.

### 6.3 Versions de contenu

- Une partie garde la `case_version` de son démarrage.
- On peut corriger une faute sans risque. En revanche, une modification de règle oblige à créer une nouvelle version, et l'ancienne reste servie jusqu'à la fin des parties en cours.
- Un test vérifie que chaque version publiée se termine avec le scénario de référence (section 16, lot 1).

### 6.4 Les images

- Portraits : 384 px. Photos des pièces : 1600 px pour le plein écran, 720 px en vignette. Le prototype fournit les deux tailles.
- En V1, les images sont dans `public/` et passent par `next/image` (formats modernes, tailles adaptées).
- En V2, elles passent dans Supabase Storage avec des URL signées, pour qu'on ne puisse pas deviner les photos à venir.
- Chaque photo a un texte alternatif, qui reprend sa légende.

---

## 7. Comptes et sauvegarde

| Besoin | Solution |
|---|---|
| Jouer sans friction | **Connexion anonyme** Supabase au premier lancement : la partie est déjà sur le serveur |
| Garder sa partie | « Sauvegarder ma partie » : rattacher un e-mail (lien magique), Google ou Apple au compte anonyme, sans perte |
| Changer d'appareil | Se connecter avec le même compte : la partie en cours se recharge |
| Sur iPhone en app native (V2) | **Se connecter avec Apple** obligatoire dès qu'une connexion Google est proposée |
| Supprimer son compte | Réglages > Supprimer : suppression en cascade de toutes les données, effective tout de suite |

**Quand proposer le rattachement.** Après la première accusation, ou au premier abonnement aux notifications, ou au bout de 24 h de jeu. Jamais avant la première action.

**Reprise de l'ancien prototype (option).** Un bouton « Importer ma partie du prototype » lit la clé `localStorage` `mobile-affaire1-v2` et l'envoie au serveur, qui vérifie la version.

---

## 8. Retour du joueur et notifications

### 8.1 L'écran « Pendant votre absence »

Il est déjà prototypé, dans la fonction `recapHTML` du prototype.

- **Quand l'afficher** : à l'ouverture ou au retour au premier plan, si l'absence dépasse 20 min ou si des événements sont arrivés depuis la dernière visite.
- **Ce qu'il contient** :
  1. depuis combien de temps le joueur est parti, et l'heure de jeu ;
  2. ce qui est arrivé entre-temps, soit les 8 dernières entrées du journal, plus un lien vers le reste ;
  3. les actions en cours, avec l'heure de leur résultat ;
  4. les actions disponibles aujourd'hui ;
  5. le prochain rendez-vous annoncé ;
  6. un bouton « Reprendre l'enquête ».
- **Le prochain rendez-vous** n'annonce jamais une surprise. Le cambriolage, la disparition de Fabrice ou l'aveu de Claire ne sont pas annoncés. Seuls les rendez-vous connus du joueur le sont : autopsie, rapport des techniciens, retour de l'avocate, dernier jour, délai.
- **Le marqueur de visite** : le client envoie la commande `seen` quand l'app passe en arrière-plan. Le serveur met alors à jour `last_seen_at` et `last_seen_journal`.

### 8.2 Les notifications push

| Type | Quand | Exemple |
|---|---|---|
| `resultat` | Un résultat arrive (mode temps réel) | « Le labo a parlé. Analyse des outils du cuvier : ouvrez le dossier. » |
| `nouvelle_journee` | 8h, s'il reste des actions et que la partie est en cours | « Dimanche, 8h. 3 actions vous attendent. » |
| `annonce_soir` | 20h | « Demain 8h : le rapport des techniciens. » |
| `delai` | Dernier jour, à 8h | « Dernier jour. Le parquet attend un nom avant 20h. » |

**Règles**
- On demande la permission **après la première action lancée en temps réel**, jamais à l'ouverture. Un écran explique d'abord pourquoi.
- **Heures de silence**, de 21h à 8h par défaut, dans le fuseau du joueur. Ce qui tombe la nuit est regroupé à 8h.
- **3 notifications par jour au maximum**. Les résultats qui arrivent à moins de 15 min d'intervalle sont regroupés.
- Pas de spoiler sur l'écran verrouillé : le texte donne envie d'ouvrir, sans révéler le résultat. Il vient du champ `notif` de l'action.
- Sur iPhone, le push web demande que la PWA soit installée. L'app affiche un mode d'emploi (Partager > Sur l'écran d'accueil) quand c'est nécessaire.

**Planification**
- À chaque commande, le serveur recalcule les rendez-vous de la partie avec `upcoming()`. Il insère ou met à jour les lignes de `notifications`, la `dedupe_key` évitant les doublons.
- Les notifications devenues sans objet sont annulées : partie terminée, passage en mode accéléré, désabonnement.
- Conversion en heure réelle : `fire_at = anchor_real + (minute_du_rendez_vous − anchor_minute) minutes`.

**Envoi** : pg_cron appelle la route d'envoi chaque minute.

```sql
-- à exécuter une fois (SQL Editor Supabase) ; secret à ranger dans Supabase Vault
select cron.schedule('notifications-chaque-minute', '* * * * *', $$
  select net.http_post(
    url     := 'https://<ton-domaine>/api/cron/notifications',
    headers := jsonb_build_object('Authorization', 'Bearer <CRON_SECRET>', 'Content-Type', 'application/json'),
    body    := '{}'::jsonb
  );
$$);
```

La route `/api/cron/notifications` :
1. vérifie le secret ;
2. lit les notifications dues : `fire_at <= now()`, non envoyées, non annulées ;
3. applique les heures de silence et le plafond quotidien ;
4. envoie via `web-push` à tous les appareils du joueur ;
5. marque `sent_at` ;
6. supprime les abonnements expirés (réponse 404 ou 410).

**E-mail (option).** Un récapitulatif à 8h pour les joueurs sans push, via Resend, désactivable en un clic.

---

## 9. Écrans et accessibilité

### 9.1 Écrans

Ils reprennent le prototype, qui sert de maquette.

| Écran | Contenu |
|---|---|
| Accueil | Catalogue des affaires, partie en cours (reprendre), connexion |
| Introduction d'affaire | Photo du domaine, pitch, mode d'emploi en 5 points, choix du rythme |
| Tri | Guide « Par où commencer » tant que le tri est fermé ; ensuite le paquet, les motifs, les filtres, l'annulation, la vue liste |
| Tableau | Mur zoomable : suspects, pièces avec vignette, post-it, fils typés, légende, commandant, accusation |
| Enquête | Actions du jour, actions en cours, conditions de disponibilité |
| Pièces | Liste avec vignettes, journal, plan du domaine |
| Fiche pièce | Photos (carrousel), texte du PV, épingler, personnes citées |
| Visionneuse | Plein écran, pincer pour zoomer, double appui, balayer entre les photos |
| Interrogatoire | Déclarations, confrontation, compteur d'erreurs |
| Verdict | Score détaillé, grade, vérité de l'affaire, rejouer |
| Pendant votre absence | Voir section 8.1 |
| Réglages | Compte, rythme, notifications, heures de silence, suppression du compte |

### 9.2 Accessibilité (viser le niveau AA du RGAA / WCAG)

- Chaque geste a son alternative en bouton : les 3 boutons de tri existent déjà, il faut aussi des boutons de zoom pour le tableau et la visionneuse.
- **Vue liste du tableau** : le mur est très visuel. Une vue liste (suspects, pièces, fils) le rend utilisable au lecteur d'écran.
- Un texte alternatif sur chaque photo, des rôles et libellés ARIA sur les cartes, un focus visible, une navigation complète au clavier (le tri au clavier existe dans le prototype).
- Contrastes AA. Respect de `prefers-reduced-motion` : on supprime les animations de swipe et de rotation des polaroïds.
- Textes agrandissables jusqu'à 200 % sans perte. Cibles tactiles de 44 px minimum.

---

## 10. API

Toutes les routes vérifient la session Supabase et que la partie appartient au joueur.

| Méthode et route | Rôle |
|---|---|
| `POST /api/games` | Créer une partie `{ caseId, mode }` et renvoyer la vue |
| `GET /api/games/:id` | Rattraper le temps, puis renvoyer la vue (avec `serverNow`) |
| `POST /api/games/:id/commands` | Appliquer une commande ou un lot de commandes |
| `POST /api/push/subscribe` | Enregistrer l'abonnement push de l'appareil |
| `DELETE /api/push/subscribe` | Désabonner l'appareil |
| `POST /api/cron/notifications` | Envoi des notifications dues (appelé par pg_cron, protégé par secret) |
| `DELETE /api/account` | Supprimer le compte et toutes ses données |

**Les commandes**

```ts
type Command =
  | { type: "launch"; actionId: string; target?: string | string[] }
  | { type: "advance"; to?: number }                         // accéléré seulement
  | { type: "sort"; cardId: number; pile: "garde" | "doute" | "ecarte"; motif: string }
  | { type: "undo" }
  | { type: "pin"; item: string } | { type: "unpin"; item: string }
  | { type: "move"; moves: { item: string; x: number; y: number }[] }
  | { type: "thread"; a: string; b: string; kind: "mobile" | "opportunite" | "preuve" | "disculpe" | "lien" }
  | { type: "unthread"; threadId: string }
  | { type: "note"; id?: string; text: string; x?: number; y?: number }
  | { type: "confront"; suspect: string; line: string; evidence: string }
  | { type: "commandant" }
  | { type: "accuse"; suspectId: number }
  | { type: "setMode"; mode: "acc" | "reel" }
  | { type: "seen" };

// Réponse
type CommandResponse = {
  view: PlayerView;            // état visible + contenu débloqué
  events: GameEvent[];         // pour les toasts et animations
  stateVersion: number;
  serverNow: string;           // ISO, pour corriger l'horloge locale
  error?: { code: string; message: string };
};
```

---

## 11. Sécurité et triche

- **Le temps vient du serveur.** Changer l'heure du téléphone n'a aucun effet.
- **Pas de solution côté client** : voir la règle anti-spoiler, section 6.1.
- **Validation de toutes les commandes par le moteur** : budget d'actions, horaires, cibles gardées, limite de 10, 3 erreurs par jour.
- **Limitation de débit** : 30 commandes par minute par joueur, plus des lots pour le tri et le tableau.
- **Secrets** (`SUPABASE_SERVICE_ROLE_KEY`, clé privée VAPID, `CRON_SECRET`) uniquement côté serveur, dans les variables d'environnement Vercel.
- Les en-têtes de sécurité (CSP) et la RLS sont activés partout.

---

## 12. Mesure : événements et indicateurs

**Événements PostHog**

`case_started`, `mode_selected`, `sort_opened`, `card_sorted {pile, motif}`, `action_launched {id}`, `result_received {id}`, `evidence_opened {id}`, `photo_zoomed {id}`, `confront {ok}`, `suspect_silenced`, `commandant {ok, ko}`, `accused {outcome, score, day}`, `day_ended_unused_actions {n}`, `recap_shown {away_min, news}`, `push_prompt_shown`, `push_optin`, `push_opened {kind}`, `account_linked {provider}`.

**Indicateurs suivis**

| Indicateur | Pourquoi |
|---|---|
| Activation : part des joueurs qui ouvrent le tri le jour 1 | Mesure la compréhension du démarrage |
| Rétention J1 et J3 (temps réel) | C'est le cœur du concept « plusieurs jours » |
| Taux de parties terminées, et jour de l'accusation | Dit si la durée est bien dosée |
| Répartition plein / fragile / vide / faux | Équilibrage de la difficulté |
| Score moyen et grades | Équilibrage du barème |
| Actions perdues en fin de journée | Lisibilité du rythme |
| Taux d'acceptation et d'ouverture des push | Valeur des rappels |
| Écarts de Jean-Luc par le piège de la voiture | Vérifie que la fausse piste fonctionne |

---

## 13. RGPD et mentions

- **Données collectées** : identifiant de compte, e-mail ou identifiant Google ou Apple, pseudo facultatif, fuseau horaire, parties, abonnements push. Rien d'autre.
- **Hébergement dans l'UE.** Analytics PostHog en instance UE, sans cookie publicitaire, avec consentement si on active l'enregistrement de sessions.
- **Droits** : export de ses données (JSON) et suppression du compte depuis les réglages.
- **Pages à prévoir** : mentions légales, politique de confidentialité, CGU.
- **Mention dans le jeu** : « Affaire et personnages fictifs. Visages et photos générés par IA. »

---

## 14. Arborescence du projet

```
mobile/
├─ CLAUDE.md
├─ content/cases/affaire-1/…            contenu (section 6), serveur uniquement
├─ public/
│  ├─ cases/affaire-1/faces/…  ev/…
│  ├─ icons/…                           icônes PWA
│  └─ manifest.webmanifest
├─ src/
│  ├─ engine/                           moteur pur (aucun import React/Supabase)
│  │  ├─ types.ts  time.ts  conditions.ts  sort.ts  board.ts
│  │  ├─ actions.ts  interro.ts  commandant.ts  scoring.ts  view.ts  upcoming.ts
│  │  ├─ cases/affaire-1.ts             gestionnaires spéciaux de l'affaire
│  │  └─ __tests__/                     Vitest : règles + partie de référence
│  ├─ app/
│  │  ├─ page.tsx                       accueil / catalogue
│  │  ├─ connexion/page.tsx
│  │  ├─ affaire/[caseId]/page.tsx      introduction
│  │  ├─ partie/[gameId]/layout.tsx     barre du haut + onglets
│  │  ├─ partie/[gameId]/{tri,tableau,enquete,pieces}/page.tsx
│  │  ├─ reglages/page.tsx
│  │  └─ api/{games,push,cron,account}/…
│  ├─ components/                       Deck, Card, Board, Thread, EvidenceSheet,
│  │                                    PhotoViewer, Interrogation, Recap, …
│  ├─ lib/supabase/{client,server,admin}.ts
│  ├─ lib/push.ts  lib/content.ts (server-only)  lib/analytics.ts
│  ├─ stores/game.ts                    Zustand : vue, file de commandes
│  └─ sw.ts                             service worker (Serwist) : cache + push
├─ supabase/migrations/0001_init.sql
└─ tests/e2e/partie.spec.ts             Playwright : partie de référence
```

---

## 15. Installation (Windows, PowerShell)

Prérequis : Node.js LTS, Git, VS Code, un compte Supabase, un compte Vercel, un dépôt GitHub. Dans PowerShell 5.1, on enchaîne les commandes avec `;` et non `&&`.

```powershell
npx create-next-app@latest mobile --typescript --eslint --tailwind --app --src-dir --import-alias "@/*"
cd mobile
npm i @supabase/supabase-js @supabase/ssr @tanstack/react-query zustand @use-gesture/react motion web-push idb posthog-js @sentry/nextjs @serwist/next
npm i -D vitest @playwright/test supabase serwist @types/web-push
npx playwright install chromium
npx supabase init
npx supabase login
npx supabase link --project-ref <ref-du-projet>
npx supabase db push
npx web-push generate-vapid-keys
```

Variables d'environnement, à mettre dans `.env.local` en local et dans Vercel en production :

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=          # serveur uniquement
NEXT_PUBLIC_VAPID_PUBLIC_KEY=
VAPID_PRIVATE_KEY=                  # serveur uniquement
VAPID_SUBJECT=mailto:<ton-email>
CRON_SECRET=                        # chaîne aléatoire longue
NEXT_PUBLIC_POSTHOG_KEY=
NEXT_PUBLIC_POSTHOG_HOST=https://eu.i.posthog.com
SENTRY_DSN=
```

Dans Supabase :
- activer les extensions `pg_cron` et `pg_net` (Database > Extensions) ;
- activer les fournisseurs Email (lien magique), Google, Apple et Anonymous (Authentication > Providers) ;
- choisir une région UE à la création du projet.

Dans Vercel :
- définir la région des fonctions sur `cdg1` ;
- ajouter les variables d'environnement.

---

## 16. Plan de livraison

| Lot | Contenu | Critères d'acceptation |
|---|---|---|
| **0. Socle** | Projet Next.js, Supabase relié, migrations, déploiement Vercel, CI GitHub (lint, types, tests) | Une page d'accueil déployée, `npm test` vert en CI |
| **1. Moteur** | Extraire le contenu du prototype dans `content/cases/affaire-1/` ; porter la logique dans `src/engine/` ; convertir les conditions en données | (a) Entonnoir des critères fiables : 100 → 64 → 18 → 9 → 6 suspects, dont Jean-Luc. (b) **Partie de référence** : la séquence du test du prototype finit en `plein` avec **675 points**. (c) Les 3 erreurs ferment un suspect jusqu'au lendemain. (d) Le témoignage de la voiture invalidé fait revenir les cartes en doute. |
| **2. Interface** | Les écrans du prototype en React : tri, tableau, enquête, pièces, visionneuse, interrogatoire, verdict | Parité visuelle et fonctionnelle avec le prototype sur iPhone (390 px) et ordinateur. Test Playwright de la partie de référence vert. |
| **3. Comptes et sauvegarde** | Connexion anonyme, rattachement, routes de commandes, verrou optimiste, synchronisation temps réel, suppression du compte | Une partie commencée sur le téléphone se reprend sur l'ordinateur. Deux appareils simultanés ne corrompent pas l'état. La suppression efface tout. |
| **4. Temps réel et retour** | Horloge serveur, rattrapage, écran « Pendant votre absence », push, heures de silence, cron | Une action lancée en temps réel envoie un push à l'heure du résultat. Rien n'est envoyé entre 21h et 8h. L'écran de retour liste exactement les nouveautés. |
| **5. Finitions et bêta** | PWA installable, mode hors ligne, analytics, Sentry, RGPD, accessibilité, pages légales | App installable sur Android et iPhone (manifeste et service worker validés dans Chrome DevTools) ; scores Lighthouse performance et accessibilité supérieurs à 90 ; audit des critères RGAA principaux ; 20 testeurs en bêta fermée |
| **6. Stores (option)** | Capacitor, push natives (FCM et APNs), Se connecter avec Apple, fiches stores | Validation App Store et Play Store |

**Définition de « terminé »** pour chaque lot :
- types stricts sans erreur et lint propre ;
- tests du moteur verts ;
- test de bout en bout vert ;
- testé sur un vrai iPhone et un vrai Android ;
- aucune clé secrète côté client.

---

## 17. Risques et points ouverts

| Sujet | Risque | Piste |
|---|---|---|
| Push sur iPhone | Il n'existe que si la PWA est installée | Mode d'emploi d'installation, e-mail de secours, puis app native au lot 6 |
| Horloge du temps réel | Journées de jeu décalées par rapport aux vraies journées | Caler sur l'heure locale (section 4.3) : **à trancher** |
| Spoilers | Images publiques, contenu dans le code | Contenu côté serveur seulement ; URL signées en V2 |
| Équilibrage | Partie trop longue, ou piège de la voiture trop punitif | Indicateurs de la section 12, réglages par version de contenu |
| Coûts | Les plans gratuits Supabase et Vercel ont des limites : mise en pause en cas d'inactivité, usage non commercial | Passer aux plans payants d'entrée de gamme avant la bêta publique (vérifier les tarifs du moment) |
| Revue Apple | Refus d'un site simplement encapsulé | Notifications natives, hors ligne, Se connecter avec Apple |
| Visages générés par IA | Ressemblance fortuite avec une personne réelle | Mention dans le jeu ; remplacement rapide d'un visage (un fichier par suspect) |

---

## 18. Pistes après la V1

- **Nouvelles affaires** au même format : le catalogue est prêt.
- **Modèle économique** : première affaire gratuite, affaires suivantes à l'unité ou en pass.
- **Mode jurés ou collectif** : le journal des commandes permet de rejouer et comparer les dossiers.
- **Éditeur d'affaires** : formulaires sur les fichiers JSON de la section 6.

---

## 19. Démarrer avec Claude Code

### 19.1 `CLAUDE.md`, à la racine du projet

```markdown
# Mobile — jeu d'enquête

## Contexte
Jeu d'enquête solo sur plusieurs jours. Spécification : docs/cahier-des-charges-mobile.md.
Le prototype de référence est dans docs/prototype/index.html : il fait foi pour les règles.

## Règles de code
- TypeScript strict. Pas de `any`.
- src/engine/ est PUR : aucun import de React, Next, Supabase, ni Date.now() / Math.random().
  L'heure et la graine sont passées en paramètre.
- Le contenu (content/cases/**) n'est importé que côté serveur (`import "server-only"`).
  Le client ne reçoit que playerView().
- Toute écriture de partie passe par POST /api/games/:id/commands (clé service_role côté serveur).
- Chaque règle de jeu portée du prototype a un test Vitest.
- Textes de l'interface en français.

## Commandes (Windows PowerShell : enchaîner avec ;)
- npm run dev
- npm test            (Vitest)
- npx playwright test
- npx supabase db push
```

Copie aussi ce cahier des charges et le prototype dans `docs/`.

### 19.2 Les premiers prompts, dans l'ordre

1. « Lis `docs/cahier-des-charges-mobile.md` et `docs/prototype/index.html`. Propose le découpage du lot 1 en tâches, sans écrire de code. »
2. « Extrais le contenu du prototype (`SUSPECTS`, `VICTIM`, `EV`, `PICS`, `TEL`, `BANQUE`, `PROOF`, `ACTIONS`, `AUTO`, `INTERRO`, `MOTIFS`, `GRADES`) vers `content/cases/affaire-1/` au format de la section 6. Convertis les conditions en `Cond`. Liste les règles qui doivent rester en gestionnaires spéciaux. »
3. « Porte le moteur dans `src/engine/`, en suivant l'annexe B. Écris d'abord les tests : l'entonnoir 100 → 64 → 18 → 9 → 6, puis la partie de référence (verdict `plein`, 675 points). »
4. « Crée la migration de la section 5, les routes de la section 10 et la connexion anonyme. »
5. Puis un lot à la fois, en vérifiant ses critères d'acceptation avant de passer au suivant.

---

## Annexe A — Glossaire

| Terme | Sens |
|---|---|
| Pile | Statut d'une carte : `atrier`, `garde`, `doute`, `ecarte` |
| Motif | Critère de tri débloqué par une pièce (code, alibi, pointure, voiture, audition, instinct) |
| Pièce | Élément du dossier : preuve matérielle, document, témoignage ou déclaration |
| Fil | Lien typé sur le tableau, entre une pièce et un suspect |
| Volet | Mobile, opportunité ou preuve : les trois parties d'un dossier plein |
| PROOF | Table secrète de ce que chaque pièce prouve réellement, et sur qui |
| Rattrapage | Faire arriver tout ce qui était dû entre deux visites (temps réel) |
| Vue joueur | Ce que le serveur envoie au client : uniquement le contenu débloqué |

## Annexe B — Du prototype aux modules

| Dans `prototype/index.html` | Va vers |
|---|---|
| `SUSPECTS`, `VICTIM`, `BY_ID`, `NAME` | `content/…/suspects.json`, `victim.json` ; utilitaires dans `engine/view.ts` |
| `START`, `DEADLINE`, `BOARD_MAX`, `JOURS`, `day`, `hhmm`, `stamp`, `isNight` | `engine/time.ts` et `case.json` |
| `EV`, `PICS`, `TEL`, `BANQUE`, `evDef` | `evidence.json`, `pictures.json`, `phones.json`, `banks.json` ; résolution dans `engine/view.ts` |
| `PROOF`, `proves` | `proof.json` (secret) ; `engine/scoring.ts` |
| `AUTO`, `fireAuto`, `invalidateVoiture` | `auto.json` ; `engine/actions.ts` et `cases/affaire-1.ts` |
| `ACTIONS`, `actionAvail`, `canAct`, `launch`, `runAction` | `actions.json` ; `engine/actions.ts` |
| `nextStop`, `advanceTo`, `fire`, `catchUp` | `engine/time.ts` |
| `MOTIFS`, `setPile`, `undo`, `FILTERS`, `buildDeck`, `triOpen` | `motifs.json` ; `engine/sort.ts` |
| `pinSuspect`, `pinEv`, `unpin`, `addThread`, `judge`, `commandant` | `engine/board.ts`, `engine/commandant.ts` |
| `INTERRO`, `confront`, `strikesOf` | `interrogations.json` ; `engine/interro.ts` |
| `submitAccuse`, `dossierFor`, `GRADES` | `engine/scoring.ts`, `scoring.json` |
| `fresh` (forme de l'état) | `engine/types.ts` : `GameState` |
| `recapHTML`, `TEASE`, `markSeen` | `engine/upcoming.ts` et le composant `Recap` |
| `renderTri`, `cardHTML`, `bindDrag` | `components/Deck`, `components/Card` |
| `renderBoard`, `threadsSVG`, `bindBoard` | `components/Board`, `components/Thread` |
| `openEvidence`, `picsHTML`, `openZoom` | `components/EvidenceSheet`, `components/PhotoViewer` |
| `CLOUD`, `cloudInit`, `cloudPush` | Remplacés par Supabase (section 7) : **ne pas porter** |
